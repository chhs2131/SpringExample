package kr.ac.inha.board.ipo.dto;

import lombok.Data;

@Data
public class PswDto {
	private String returnValue;
}
