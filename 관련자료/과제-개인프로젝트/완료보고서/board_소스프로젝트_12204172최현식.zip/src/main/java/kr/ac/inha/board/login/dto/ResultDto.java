package kr.ac.inha.board.login.dto;

import lombok.Data;

@Data
public class ResultDto {
	private String status;
	private String errMsg;
}
