package kr.ac.inha.board.board.service;

import java.util.List;

import kr.ac.inha.board.board.dto.BoardDto;
import kr.ac.inha.board.board.dto.ReplyDto;

public interface BoardService {
	List<BoardDto> selectBoardList() throws Exception;

	void insertBoard(BoardDto board) throws Exception;
	
	BoardDto selectBoardDetail(int boardIdx) throws Exception;
	void updateBoard(BoardDto board) throws Exception;
	void deleteBoard(int boardIdx) throws Exception;

	// 댓글 관련
	List<ReplyDto> selectReplyList(int boardIdx) throws Exception;
	ReplyDto selectReplyDetail(int replyNo) throws Exception;
	void insertReply(ReplyDto board) throws Exception;
	void updateReply(ReplyDto reply) throws Exception;
	void deleteReply(int replyNo) throws Exception;
}
