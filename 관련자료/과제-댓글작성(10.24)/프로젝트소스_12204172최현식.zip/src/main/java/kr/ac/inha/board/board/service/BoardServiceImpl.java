package kr.ac.inha.board.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.inha.board.board.dto.BoardDto;
import kr.ac.inha.board.board.dto.ReplyDto;
import kr.ac.inha.board.board.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService {
	@Autowired
	private BoardMapper boardMapper;

	@Override
	public List<BoardDto> selectBoardList() throws Exception {
		return boardMapper.selectBoardList();
	}

	@Override
	public void insertBoard(BoardDto board) throws Exception {
		boardMapper.insertBoard(board);
	}
	
	@Override
	public BoardDto selectBoardDetail(int boardIdx) throws Exception {
		BoardDto board = boardMapper.selectBoardDetail(boardIdx);
		boardMapper.updateHitCount(boardIdx);
		return board;
	}

	@Override
	public void updateBoard(BoardDto board) throws Exception {
		boardMapper.updateBoard(board);
	}

	@Override
	public void deleteBoard(int boardIdx) throws Exception {
		boardMapper.deleteBoard(boardIdx);
	}

	// 댓글 기능
	@Override
	public List<ReplyDto> selectReplyList(int boardIdx) throws Exception {
		return boardMapper.selectReplyList(boardIdx);
	}

	@Override
	public ReplyDto selectReplyDetail(int replyNo) throws Exception{
		ReplyDto reply = boardMapper.selectReplyDetail(replyNo);
		//boardMapper.updateReplyCount(reply.getBoardIdx(), replyNo);
		return reply;
	}

	@Override
	public void insertReply(ReplyDto board) throws Exception{
		boardMapper.insertReply(board);
		boardMapper.updateReplyCount(board.getBoardIdx(), 1);
	}

	@Override
	public void updateReply(ReplyDto reply) throws Exception {
		boardMapper.updateReply(reply);
	}

	@Override
	public void deleteReply(int replyNo) throws Exception {
		ReplyDto reply = boardMapper.selectReplyDetail(replyNo);
		boardMapper.updateReplyCount(reply.getBoardIdx(), -1);
		boardMapper.deleteReply(replyNo);
	}

}
