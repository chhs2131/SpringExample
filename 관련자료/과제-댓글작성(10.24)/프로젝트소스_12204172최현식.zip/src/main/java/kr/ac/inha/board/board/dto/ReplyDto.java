package kr.ac.inha.board.board.dto;

import lombok.Data;

@Data
public class ReplyDto {
	private int boardIdx;
	private int replyNo;
	private String replyMemo;
	private String createdDatetime;
	private String creatorId;
}
