package kr.ac.inha.board.board.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import kr.ac.inha.board.board.dto.BoardDto;
import kr.ac.inha.board.board.dto.ReplyDto;

@Mapper
public interface BoardMapper {
	// 게시글 관련
	List<BoardDto> selectBoardList() throws Exception;

	void insertBoard(BoardDto board) throws Exception;

	BoardDto selectBoardDetail(int boardIdx) throws Exception;
	void updateHitCount(int boardIdx) throws Exception;
	void updateBoard(BoardDto board) throws Exception;
	void deleteBoard(int boardIdx) throws Exception;
	
	// 댓글 관련
	List<ReplyDto> selectReplyList(int boardIdx) throws Exception;
	ReplyDto selectReplyDetail(int replyNo) throws Exception;
	void updateReplyCount(@Param("boardIdx") int boardIdx, @Param("interval") int interval) throws Exception;
	void insertReply(ReplyDto board) throws Exception;
	void updateReply(ReplyDto reply) throws Exception;
	void deleteReply(int replyNo) throws Exception;
}
